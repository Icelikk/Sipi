var searchData=
[
  ['logincontroller_0',['LoginController',['../class_login_controller.html',1,'']]]
];
