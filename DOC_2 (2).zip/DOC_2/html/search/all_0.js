var searchData=
[
  ['configure_0',['configure',['../class_security_config.html#a0719c322b69aade34dddd248fed531a1',1,'SecurityConfig.configure(AuthenticationManagerBuilder auth)'],['../class_security_config.html#ab915edfd0b4087718359a0377ece2e57',1,'SecurityConfig.configure(HttpSecurity http)']]]
];
